/**
 * i18n dictionary only.
 * Rendering/binding is handled in assets/js/main.js (ES module).
 */
window.I18N_DICT = {
  ar: {
    dir: "rtl",
    nav_home: "الرئيسية",
    nav_about: "من نحن",
    nav_products: "المنتجات",
    nav_contact: "تواصل معنا",
    nav_auth: "الحساب",
    lang_btn: "English",

    footer_tagline: "شركة الودق لصناعة ورق الجدران المحدودة — العراق، بابل",
    footer_rights: "جميع الحقوق محفوظة",
    phone_label: "الهاتف",
    email_label: "البريد",
    address_label: "العنوان",

    home_badge: "مصنع ورق جدران — جودة وتصاميم معاصرة",
    home_title: "شركة الودق لصناعة ورق الجدران المحدودة",
    home_sub:
      "نصنع ورق جدران بمواصفات تشغيلية عالية، مع تنوع واسع في الخامات والتشطيبات. نخدم الأسواق المحلية والمشاريع التجارية والسكنية في العراق.",
    home_cta_products: "استعراض المنتجات",
    home_cta_quote: "اطلب عرض سعر",
    kpi1: "تصاميم متعددة",
    kpi2: "خامات وتشطيبات",
    kpi3: "توريد للمشاريع",
    kpi4: "ضبط جودة",

    home_why_title: "لماذا الودق؟",
    home_why_1_t: "جودة قابلة للقياس",
    home_why_1_d: "رقابة على السماكة، ثبات اللون، ومقاومة الاستخدام وفق متطلبات المشاريع.",
    home_why_2_t: "تنوع في المواد",
    home_why_2_d: "Vinyl، Non-woven، وتشطيبات مطفية/لامعة حسب خطوط المنتج.",
    home_why_3_t: "جاهزية توريد",
    home_why_3_d: "إدارة طلبات وجدولة تسليم لدعم المقاولين والموزعين.",

    home_services_title: "ماذا نقدم؟",
    home_services_li1: "ورق جدران للاستخدام السكني والتجاري.",
    home_services_li2: "تشكيلات مودرن وكلاسيك وخيارات حسب الطلب للمشاريع.",
    home_services_li3: "توصيات تركيب وخدمات دعم للموزعين.",
    home_services_li4: "تسعير بالجملة للموزعين وشركات التنفيذ.",

    about_badge: "من نحن",
    about_title: "خبرة صناعية محلية تدعم جودة المنتج واستقرار التوريد.",
    about_p:
      "شركة الودق لصناعة ورق الجدران المحدودة تعمل في محافظة بابل — العراق. نركز على جودة المواد، دقة الطباعة، وثبات الألوان مع تطوير مستمر في التصاميم بما يلائم ذوق السوق.",
    about_vision_t: "رؤيتنا",
    about_vision_p: "أن نكون الخيار الأول لورق الجدران المصنّع محلياً في العراق من حيث الجودة والتنوع.",
    about_values_t: "قيمنا",
    about_val1: "الجودة والانضباط التشغيلي.",
    about_val2: "الشفافية في المواصفات والطلب.",
    about_val3: "الابتكار في التصميم والخامة.",
    about_val4: "خدمة العملاء وشراكات التوريد.",

    prod_badge: "المنتجات",
    prod_title: "منتجات ورق جدران بخيارات متعددة للخامة والتشطيب.",
    prod_p:
      "اختر الفئة المناسبة واطلب عينات أو عرض سعر. يمكن توفير مواصفات خاصة للمشاريع حسب الكمية.",
    prod_cta_contact: "اطلب عينات/سعر",

    p1_tag: "Vinyl",
    p1_name: "ورق جدران فينيل",
    p1_desc: "مقاومة أعلى للرطوبة وسهولة تنظيف، مناسب للمنازل والمكاتب.",

    p2_tag: "Non-woven",
    p2_name: "Non-woven",
    p2_desc: "تركيب أسهل وثبات أفضل، مناسب لمساحات كبيرة ومشاريع.",

    p3_tag: "Classic",
    p3_name: "كلاسيك",
    p3_desc: "نقوش كلاسيكية وألوان متوازنة للديكورات التقليدية.",

    p4_tag: "Modern",
    p4_name: "مودرن",
    p4_desc: "تصاميم عصرية وخطوط بسيطة لمظهر حديث.",

    p5_tag: "Kids",
    p5_name: "غرف الأطفال",
    p5_desc: "ألوان مبهجة وخيارات آمنة مناسبة لغرف الأطفال.",

    p6_tag: "Custom",
    p6_name: "حسب الطلب للمشاريع",
    p6_desc: "تنفيذ تصميم/مواصفة خاصة عند توفر الحد الأدنى للطلب.",

    contact_badge: "تواصل معنا",
    contact_title: "للعينات، التسعير بالجملة، أو توريد المشاريع — تواصل الآن.",
    contact_p:
      "املأ النموذج وسنرد عليك. في الموقع الحقيقي يتم ربط النموذج ببريد الشركة/CRM (هنا نسخة جاهزة للربط).",
    c_company: "الشركة (اختياري)",
    c_name: "الاسم",
    c_email: "البريد الإلكتروني",
    c_phone: "الهاتف (اختياري)",
    c_need: "نوع الطلب",
    c_details: "تفاصيل الطلب",
    c_submit: "إرسال",

    need1: "عينات",
    need2: "تسعير جملة",
    need3: "مشروع (توريد)",
    need4: "شراكة توزيع",

    contact_info_title: "بيانات الشركة",
    city: "العراق — بابل",
    map_title: "الموقع على الخريطة",
    whatsapp_btn: "واتساب",

    auth_badge: "الحساب",
    login_title: "تسجيل الدخول",
    register_title: "إنشاء حساب",
    name_label: "الاسم",
    password_label: "كلمة المرور",
    login_btn: "دخول",
    register_btn: "إنشاء حساب",
    auth_note: "تنبيه: هذا تسجيل دخول تجريبي للواجب فقط ويتم حفظ البيانات داخل المتصفح.",

    feedback_badge: "ملاحظات",
    feedback_title: "إرسال ملاحظة",
    feedback_desc: "أخبرنا برأيك حول الموقع أو المنتجات.",
    rating_label: "التقييم",
    message_label: "الرسالة",
    feedback_btn: "إرسال الملاحظة",

    media_title: "محتوى وسائط: المصنع والمنتج",
    media_desc: "محتوى وسائط للواجب (استبدل رابط الفيديو بفيديو المصنع الحقيقي).",
    innovation_title: "فكرة مبتكرة: مُعاين ورق الجدران",
    innovation_desc: "فكرة مبتكرة: تمكين المستخدم من معاينة ورق الجدران على صورة غرفة (MVP).",
    innovation_note: "هذه ميزة MVP مبسطة (Canvas) ويمكن تطويرها لاحقاً لتكون أكثر واقعية.",
    viz_badge: "المُعاين",
    viz_title: "معاينة ورق الجدران على صورة غرفة",
    viz_desc: "ارفع صورة غرفة واختر النمط للتحقق من المظهر بسرعة (MVP).",
    viz_upload: "رفع صورة",
    viz_pattern: "النمط",
    viz_opacity: "الشفافية",
    viz_scale: "المقياس",
    viz_reset: "إعادة ضبط",
    viz_geo: "هندسي",
    viz_floral: "زهري",
    viz_stripes: "خطوط"
  },

  en: {
    dir: "ltr",
    nav_home: "Home",
    nav_about: "About",
    nav_products: "Products",
    nav_contact: "Contact",
    nav_auth: "Account",
    lang_btn: "العربية",

    footer_tagline: "Al-Wadaq Wallpaper Manufacturing Co. Ltd — Babel, Iraq",
    footer_rights: "All rights reserved",
    phone_label: "Phone",
    email_label: "Email",
    address_label: "Address",

    home_badge: "Wallpaper manufacturer — quality and modern designs",
    home_title: "Al-Wadaq Wallpaper Manufacturing Co. Ltd",
    home_sub:
      "We manufacture high-quality wallpapers with a wide range of materials and finishes. We serve local Iraqi markets and support residential and commercial projects.",
    home_cta_products: "View Products",
    home_cta_quote: "Request a Quote",
    kpi1: "Multiple designs",
    kpi2: "Materials & finishes",
    kpi3: "Project supply",
    kpi4: "Quality control",

    home_why_title: "Why Al-Wadaq?",
    home_why_1_t: "Measurable quality",
    home_why_1_d: "Controls for thickness, color consistency, and durability based on project needs.",
    home_why_2_t: "Material variety",
    home_why_2_d: "Vinyl, non-woven, and matte/gloss finishes across product lines.",
    home_why_3_t: "Supply readiness",
    home_why_3_d: "Order management and delivery scheduling for contractors and distributors.",

    home_services_title: "What we offer",
    home_services_li1: "Wallpaper for residential and commercial use.",
    home_services_li2: "Modern/classic collections and project-ready customization options.",
    home_services_li3: "Installation guidance and distributor support.",
    home_services_li4: "Wholesale pricing for distributors and contractors.",

    about_badge: "About",
    about_title: "Local manufacturing with dependable quality and stable supply.",
    about_p:
      "Al-Wadaq Wallpaper Manufacturing Co. Ltd operates in Babel Province, Iraq. We focus on material quality, printing accuracy, and color consistency, with continuous design development to match market taste.",
    about_vision_t: "Our Vision",
    about_vision_p: "To be Iraq’s leading locally manufactured wallpaper brand in quality and variety.",
    about_values_t: "Our Values",
    about_val1: "Quality and operational discipline.",
    about_val2: "Specification and order transparency.",
    about_val3: "Innovation in design and materials.",
    about_val4: "Customer service and supply partnerships.",

    prod_badge: "Products",
    prod_title: "Wallpaper products across materials and finish options.",
    prod_p:
      "Choose the suitable category and request samples or a quote. Project-specific specs are available based on quantity.",
    prod_cta_contact: "Request Samples/Quote",

    p1_tag: "Vinyl",
    p1_name: "Vinyl Wallpaper",
    p1_desc: "Better moisture resistance and easy cleaning for homes and offices.",

    p2_tag: "Non-woven",
    p2_name: "Non-woven Wallpaper",
    p2_desc: "Easier installation and strong stability for large areas and projects.",

    p3_tag: "Classic",
    p3_name: "Classic Collection",
    p3_desc: "Traditional patterns and balanced colors for classic interiors.",

    p4_tag: "Modern",
    p4_name: "Modern Collection",
    p4_desc: "Clean lines and contemporary designs for a modern look.",

    p5_tag: "Kids",
    p5_name: "Kids Rooms",
    p5_desc: "Cheerful colors and safe options for children’s rooms.",

    p6_tag: "Custom",
    p6_name: "Project Customization",
    p6_desc: "Custom design/specification available subject to minimum order quantity.",

    contact_badge: "Contact",
    contact_title: "Samples, wholesale pricing, or project supply — contact us.",
    contact_p:
      "Fill the form and we will respond. In production, connect this form to email/CRM.",
    c_company: "Company (optional)",
    c_name: "Full name",
    c_email: "Email",
    c_phone: "Phone (optional)",
    c_need: "Inquiry type",
    c_details: "Details",
    c_submit: "Send",

    need1: "Samples",
    need2: "Wholesale pricing",
    need3: "Project supply",
    need4: "Distribution partnership",

    contact_info_title: "Company Details",
    city: "Babel, Iraq",
    map_title: "Location on Map",
    whatsapp_btn: "WhatsApp",

    auth_badge: "Account",
    login_title: "Login",
    register_title: "Register",
    name_label: "Name",
    password_label: "Password",
    login_btn: "Login",
    register_btn: "Create account",
    auth_note: "Note: demo auth for assignment only; data is stored locally in your browser.",

    feedback_badge: "Feedback",
    feedback_title: "Send Feedback",
    feedback_desc: "Tell us what you think about the website or products.",
    rating_label: "Rating",
    message_label: "Message",
    feedback_btn: "Send feedback",

    media_title: "Media Content: Factory & Product",
    media_desc: "Media content for the assignment (replace the video URL with your real factory video).",
    innovation_title: "Innovation: Wallpaper Visualizer",
    innovation_desc: "Innovative concept: preview wallpaper styles on a room photo (MVP).",
    innovation_note: "This is a simplified MVP (Canvas) that can be extended for realism.",
    viz_badge: "Visualizer",
    viz_title: "Preview wallpaper on a room photo",
    viz_desc: "Upload a room image and pick a pattern to quickly validate the look (MVP).",
    viz_upload: "Upload image",
    viz_pattern: "Pattern",
    viz_opacity: "Opacity",
    viz_scale: "Scale",
    viz_reset: "Reset",
    viz_geo: "Geometric",
    viz_floral: "Floral",
    viz_stripes: "Stripes"
  }
};
