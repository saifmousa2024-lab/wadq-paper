export const Storage = {
  getJSON(key, fallback){
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch { return fallback; }
  },
  setJSON(key, value){ localStorage.setItem(key, JSON.stringify(value)); },
  get(key, fallback=null){ return localStorage.getItem(key) ?? fallback; },
  set(key, value){ localStorage.setItem(key, value); },
  remove(key){ localStorage.removeItem(key); }
};
