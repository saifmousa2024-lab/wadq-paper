import { Storage } from "./storage.js";
import { toast } from "./ui.js";
import { getSession } from "./auth.module.js";

const LS_LANG = "alwadaq_lang";
const LS_LEADS = "alwadaq_leads";
const LS_FEEDBACK = "alwadaq_feedback";

function getLang(){ return Storage.get(LS_LANG, "ar"); }

function isEmail(v){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

export function bindContactForm(){
  const form = document.getElementById("contactForm");
  if(!form) return;

  form.addEventListener("submit",(e)=>{
    e.preventDefault();
    const name = (document.getElementById("cName")?.value || "").trim();
    const email = (document.getElementById("cEmail")?.value || "").trim();
    const details = (document.getElementById("cDetails")?.value || "").trim();

    if(!name || !email || !details || !isEmail(email)){
      toast(getLang()==="ar" ? "يرجى إدخال الاسم وبريد صحيح والتفاصيل." : "Enter name, valid email, and details.");
      return;
    }

    const payload = {
      company: (document.getElementById("cCompany")?.value || "").trim(),
      name, email,
      phone: (document.getElementById("cPhone")?.value || "").trim(),
      need: (document.getElementById("cNeed")?.value || ""),
      details,
      at: new Date().toISOString()
    };

    const list = Storage.getJSON(LS_LEADS, []);
    list.unshift(payload);
    Storage.setJSON(LS_LEADS, list);

    toast(getLang()==="ar" ? "تم إرسال الطلب بنجاح." : "Inquiry sent successfully.");
    form.reset();
  });
}

export function bindFeedbackForm(){
  const form = document.getElementById("feedbackForm");
  if(!form) return;

  form.addEventListener("submit",(e)=>{
    e.preventDefault();
    const sess = getSession();
    const name = ((document.getElementById("fName")?.value || "").trim() || (sess?.name || ""));
    const email = ((document.getElementById("fEmail")?.value || "").trim() || (sess?.email || ""));
    const rating = (document.getElementById("fRating")?.value || "5");
    const msg = ((document.getElementById("fMessage")?.value || "").trim());

    if(!msg){
      toast(getLang()==="ar" ? "اكتب ملاحظتك أولاً." : "Please write your feedback.");
      return;
    }
    if(email && !isEmail(email)){
      toast(getLang()==="ar" ? "البريد غير صحيح." : "Invalid email.");
      return;
    }

    const item = {name, email, rating, msg, at: new Date().toISOString()};
    const list = Storage.getJSON(LS_FEEDBACK, []);
    list.unshift(item);
    Storage.setJSON(LS_FEEDBACK, list);

    toast(getLang()==="ar" ? "شكراً! تم إرسال الملاحظة." : "Thank you! Feedback sent.");
    form.reset();
  });
}
