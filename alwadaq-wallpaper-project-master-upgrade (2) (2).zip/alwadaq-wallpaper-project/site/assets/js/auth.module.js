import { Storage } from "./storage.js";
import { toast } from "./ui.js";

const LS_USERS = "alwadaq_users";
const LS_SESSION = "alwadaq_session";
const LS_LANG = "alwadaq_lang";

function getLang(){ return Storage.get(LS_LANG, "ar"); }

function hash(s){
  // demo-only hash (not for production)
  let h = 0;
  for(let i=0;i<s.length;i++) h = (h<<5) - h + s.charCodeAt(i);
  return String(h >>> 0);
}

export function getSession(){
  return Storage.getJSON(LS_SESSION, null);
}

export function setSession(sess){
  if(sess) Storage.setJSON(LS_SESSION, sess);
  else Storage.remove(LS_SESSION);
  renderSessionSlot();
}

export function renderSessionSlot(){
  const sess = getSession();
  const slot = document.getElementById("sessionSlot");
  if(!slot) return;

  if(sess && sess.email){
    slot.innerHTML = `
      <span class="badge" style="background:#eef2ff;color:#3730a3;border:1px solid #e0e7ff;">
        ${sess.email}
      </span>
      <button class="btn" type="button" id="logoutBtn">Logout</button>
    `;
    document.getElementById("logoutBtn")?.addEventListener("click", ()=>{
      setSession(null);
      toast(getLang()==="ar" ? "تم تسجيل الخروج." : "Logged out.");
    });
  } else {
    slot.innerHTML = `<a class="btn primary" href="auth.html">Login / Register</a>`;
  }
}

export function bindAuthForms(){
  const regForm = document.getElementById("registerForm");
  const loginForm = document.getElementById("loginForm");

  if(regForm){
    regForm.addEventListener("submit",(e)=>{
      e.preventDefault();
      const name = document.getElementById("rName")?.value?.trim();
      const email = document.getElementById("rEmail")?.value?.trim().toLowerCase();
      const pass = document.getElementById("rPassword")?.value || "";
      if(!name || !email || pass.length < 6){
        toast(getLang()==="ar" ? "يرجى إدخال اسم وبريد صحيح وكلمة مرور (6+)." : "Enter valid name/email and password (6+).");
        return;
      }
      const users = Storage.getJSON(LS_USERS, []);
      if(users.some(u=>u.email===email)){
        toast(getLang()==="ar" ? "هذا البريد مسجل مسبقاً." : "Email already registered.");
        return;
      }
      users.push({name, email, passHash: hash(pass), createdAt: new Date().toISOString()});
      Storage.setJSON(LS_USERS, users);
      setSession({email, name, at: new Date().toISOString()});
      toast(getLang()==="ar" ? "تم إنشاء الحساب." : "Account created.");
      regForm.reset();
      setTimeout(()=> location.href="index.html", 450);
    });
  }

  if(loginForm){
    loginForm.addEventListener("submit",(e)=>{
      e.preventDefault();
      const email = document.getElementById("lEmail")?.value?.trim().toLowerCase();
      const pass = document.getElementById("lPassword")?.value || "";
      const users = Storage.getJSON(LS_USERS, []);
      const user = users.find(u=>u.email===email);
      if(!user || user.passHash !== hash(pass)){
        toast(getLang()==="ar" ? "بيانات الدخول غير صحيحة." : "Invalid credentials.");
        return;
      }
      setSession({email: user.email, name: user.name, at: new Date().toISOString()});
      toast(getLang()==="ar" ? "تم تسجيل الدخول." : "Logged in.");
      loginForm.reset();
      setTimeout(()=> location.href="index.html", 450);
    });
  }

  renderSessionSlot();
}
