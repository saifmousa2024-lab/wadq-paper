import { Storage } from "./storage.js";
import { toast } from "./ui.js";

const LS_LANG = "alwadaq_lang";

function getLang(){ return Storage.get(LS_LANG, "ar"); }

export function bindVisualizer(){
  const canvas = document.getElementById("vizCanvas");
  const file = document.getElementById("vizFile");
  const pattern = document.getElementById("vizPattern");
  const opacity = document.getElementById("vizOpacity");
  const scale = document.getElementById("vizScale");
  const reset = document.getElementById("vizReset");

  if(!canvas || !file || !pattern || !opacity || !scale || !reset) return;

  const ctx = canvas.getContext("2d");
  const img = new Image();
  img.crossOrigin = "anonymous";

  function fitAndDraw(){
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);

    // background
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0,0,w,h);

    // draw room image (fit)
    const r = Math.min(w / img.width, h / img.height);
    const dw = img.width * r;
    const dh = img.height * r;
    const dx = (w - dw) / 2;
    const dy = (h - dh) / 2;
    ctx.drawImage(img, dx, dy, dw, dh);

    // overlay wallpaper pattern (simple MVP)
    const op = Number(opacity.value || 0.35);
    const sc = Number(scale.value || 1.0);
    ctx.save();
    ctx.globalAlpha = op;
    ctx.globalCompositeOperation = "multiply";
    const pat = pattern.value;

    // create pattern tiles
    const tile = document.createElement("canvas");
    tile.width = Math.max(200, Math.floor(220 * sc));
    tile.height = Math.max(200, Math.floor(220 * sc));
    const tctx = tile.getContext("2d");

    // base
    tctx.fillStyle = "#f8fafc";
    tctx.fillRect(0,0,tile.width,tile.height);

    if(pat === "geo"){
      tctx.strokeStyle = "rgba(99,102,241,.45)";
      tctx.lineWidth = 6;
      for(let x=0; x<tile.width; x+=60){
        tctx.beginPath(); tctx.moveTo(x,0); tctx.lineTo(x+60,tile.height); tctx.stroke();
      }
      tctx.strokeStyle = "rgba(14,165,164,.45)";
      for(let y=0; y<tile.height; y+=60){
        tctx.beginPath(); tctx.moveTo(0,y); tctx.lineTo(tile.width,y+60); tctx.stroke();
      }
    } else if(pat === "floral"){
      tctx.fillStyle = "rgba(245,158,11,.45)";
      for(let i=0;i<14;i++){
        const x = (i*47) % tile.width;
        const y = (i*83) % tile.height;
        tctx.beginPath();
        tctx.arc(x+30,y+30,18,0,Math.PI*2);
        tctx.fill();
      }
    } else { // stripes
      tctx.fillStyle = "rgba(14,165,164,.40)";
      for(let x=0; x<tile.width; x+=34){
        tctx.fillRect(x,0,14,tile.height);
      }
      tctx.fillStyle = "rgba(99,102,241,.30)";
      for(let x=17; x<tile.width; x+=34){
        tctx.fillRect(x,0,10,tile.height);
      }
    }

    const p = ctx.createPattern(tile, "repeat");
    ctx.fillStyle = p;
    ctx.fillRect(dx, dy, dw, dh);
    ctx.restore();
  }

  function loadFromFile(f){
    const reader = new FileReader();
    reader.onload = () => { img.src = reader.result; };
    reader.readAsDataURL(f);
  }

  img.onload = ()=> fitAndDraw();

  // default image placeholder (simple gradient)
  (function(){
    const tmp = document.createElement("canvas");
    tmp.width = 1200; tmp.height = 800;
    const t = tmp.getContext("2d");
    const g = t.createLinearGradient(0,0,1200,800);
    g.addColorStop(0,"#e0f2fe"); g.addColorStop(.5,"#eef2ff"); g.addColorStop(1,"#fef3c7");
    t.fillStyle = g; t.fillRect(0,0,1200,800);
    t.fillStyle="rgba(15,23,42,.25)"; t.fillRect(180,160,840,520);
    t.fillStyle="rgba(255,255,255,.82)"; t.fillRect(220,200,760,440);
    t.fillStyle="rgba(15,23,42,.12)"; t.fillRect(250,230,320,180);
    t.fillRect(610,230,340,180);
    t.fillRect(250,440,700,160);
    img.src = tmp.toDataURL("image/png");
  })();

  file.addEventListener("change", ()=>{
    const f = file.files?.[0];
    if(!f) return;
    if(!f.type.startsWith("image/")){
      toast(getLang()==="ar" ? "الملف يجب أن يكون صورة." : "File must be an image.");
      return;
    }
    loadFromFile(f);
  });

  [pattern, opacity, scale].forEach(el=> el.addEventListener("input", fitAndDraw));

  reset.addEventListener("click", ()=>{
    pattern.value = "geo";
    opacity.value = "0.35";
    scale.value = "1";
    fitAndDraw();
  });

  // responsive canvas resize
  function resize(){
    const parent = canvas.parentElement;
    const w = Math.min(980, parent?.clientWidth || 980);
    canvas.width = w;
    canvas.height = Math.round(w * 0.62);
    fitAndDraw();
  }
  window.addEventListener("resize", resize);
  resize();
}
