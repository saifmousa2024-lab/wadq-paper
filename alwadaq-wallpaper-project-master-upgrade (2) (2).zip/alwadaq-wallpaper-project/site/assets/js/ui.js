export function toast(msg){
  const el = document.getElementById("toast");
  if(!el){ alert(msg); return; }
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(()=> el.classList.remove("show"), 2800);
}

export function setActiveNav(){
  const path = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll("[data-nav]").forEach(a=>{
    const target = (a.getAttribute("href") || "").toLowerCase();
    a.classList.toggle("active", target === path);
  });
}

export function setupMobileMenu(){
  const menuBtn = document.getElementById("menuBtn");
  const navLinks = document.getElementById("navLinks");
  if(menuBtn && navLinks){
    menuBtn.addEventListener("click", ()=> navLinks.classList.toggle("open"));
  }
}
