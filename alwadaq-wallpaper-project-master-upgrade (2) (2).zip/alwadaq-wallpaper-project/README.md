# Al‑Wadaq Wallpaper Website (Bilingual) — Assignment Project

This repository contains a responsive, bilingual (Arabic/English) static website for **Al‑Wadaq Wallpaper Manufacturing Co. Ltd (Babel, Iraq)**.

## Features (Assignment Requirements)
- **Three+ pages:** Home, About, Products, Contact + Account (Auth)
- **Responsive navigation bar** with mobile menu
- **User Authentication (Demo):** Register/Login stored in browser localStorage (for assignment only)
- **Feedback form** with rating + message (stored locally for demo)
- **Media content:** embedded video on Home page
- **Bilingual UI:** Arabic/English toggle with RTL/LTR support

## Project Structure
```
site/
  index.html
  about.html
  products.html
  contact.html
  auth.html
  visualizer.html
  assets/
    css/
      style.css
    js/
      i18n.js
      main.js
      storage.js
      ui.js
      auth.module.js
      forms.js
      visualizer.js
    img/
      logo.svg
  sitemap.xml
  robots.txt

tests/
  TEST_PLAN.md
  test-runner.html
```
site/
  index.html
  about.html
  products.html
  contact.html
  auth.html
  assets/
    css/
      style.css
    js/
      i18n.js
      auth.js
    img/
      logo.svg
  sitemap.xml
  robots.txt
```

## Run Locally
Option 1 (simple):
- Open `site/index.html` in your browser.

Option 2 (recommended, local server):
- Using VS Code: install **Live Server** extension and run on `site/index.html`.
- Or using Python:
  - `python -m http.server 8080`
  - open `http://localhost:8080/site/`

## Deployment (Get a Live URL)
### Netlify
1. Create a Netlify account
2. **Add new site → Deploy manually**
3. Drag-and-drop the **site/** folder
4. Netlify will generate a live URL

### GitHub Pages
1. Push this repository to GitHub
2. Settings → Pages → Deploy from branch
3. Select `main` and folder `/ (root)`
4. Set **Pages source** to `/site` (or move `site/` contents to root)

## Notes (Important)
- Authentication is **demo-only** and not secure for production.
- Replace placeholder phone/email/WhatsApp with real company details before real use.

## License
For academic/assignment use.
