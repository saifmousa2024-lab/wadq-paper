# Test Plan — Al‑Wadaq Website (Bilingual Static Site)

## Scope
Functional and usability testing for:
- Navigation & responsive menu
- Language toggle (Arabic RTL / English LTR)
- Demo authentication (register/login/logout)
- Contact form + validation
- Feedback form + validation
- Visualizer MVP (Canvas overlay) basic behavior
- Accessibility baseline (keyboard focus, skip link)
- Cross‑browser smoke tests

## Test Environments
- Desktop: Chrome/Edge/Firefox (latest)
- Mobile: Android Chrome / iOS Safari (if available)
- Screen sizes: 360×800, 768×1024, 1366×768, 1920×1080

## Entry/Exit Criteria
- Entry: Build is deployed locally or on Netlify; all files load without console errors.
- Exit: All P0/P1 tests pass; no blocking defects remain.

## Test Cases (Summary)
### P0 — Must Pass
1. Navbar links open correct pages.
2. Mobile menu opens/closes and links are clickable.
3. Language toggle switches text + direction (RTL/LTR).
4. Register → session shown in navbar → logout works.
5. Login with registered user works.
6. Contact form blocks submission on missing/invalid fields.
7. Feedback form blocks empty message; stores feedback.
8. Visualizer loads and responds to pattern/opacity/scale.
9. No JS console errors on page load (all pages).

### P1 — Should Pass
- Visualizer accepts uploaded image.
- Forms reset after successful submit.
- Keyboard navigation: tab order is logical; skip link works.

## Defect Template
- Title:
- Steps to reproduce:
- Expected:
- Actual:
- Severity (P0/P1/P2):
- Page/Browser:
